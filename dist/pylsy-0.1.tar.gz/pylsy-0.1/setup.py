from distutils.core import setup
setup(
    name='pylsy',
    packages=['pylsy'],
    version='0.1',
    description='A simple Python library for easily displaying tabular data ina visually appealing ASCII table format',
    author='leviathan',
    author_email='leviathan1995@outlook.com',
    url='https://github.com/Leviathan1995/Pylsy',
)
